Transient, moving mesh
----------------------

cylinderMesh/
    For generating (2D) mesh cylinder mesh

cylinderAndBackground/
    BlockMesh for background and running

    0.orig/pointDisplacement set up to use table driven motion. Set bc of
    walls to e.g. uniformValue (0 0 0) to have steady mesh.
